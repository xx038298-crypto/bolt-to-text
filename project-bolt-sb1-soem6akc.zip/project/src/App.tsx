import React, { useState, useCallback } from 'react';
import { Copy, Trash2, ArrowRight, FileText } from 'lucide-react';

function App() {
  const [inputText, setInputText] = useState('');
  const [copySuccess, setCopySuccess] = useState(false);

  // 处理输入文本，将空格分隔的文本转换为逗号分隔
  const processedText = useCallback(() => {
    if (!inputText.trim()) return '';
    
    return inputText
      .trim()
      .split(/\s+/) // 使用正则表达式分割多个空格
      .filter(text => text.length > 0) // 过滤空字符串
      .join(',');
  }, [inputText]);

  // 复制功能
  const handleCopy = async () => {
    const textToCopy = processedText();
    if (!textToCopy) return;

    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } catch (err) {
      console.error('复制失败:', err);
    }
  };

  // 清空输入
  const handleClear = () => {
    setInputText('');
  };

  const outputText = processedText();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* 头部 */}
      <header className="bg-white/80 backdrop-blur-sm shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                文本格式转换器
              </h1>
              <p className="text-gray-600 text-sm">将空格分隔的文本转换为逗号分隔格式</p>
            </div>
          </div>
        </div>
      </header>

      {/* 主内容区 */}
      <main className="max-w-6xl mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* 输入区域 */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-800 flex items-center space-x-2">
                <span>输入文本</span>
              </h2>
              <button
                onClick={handleClear}
                className="flex items-center space-x-2 px-3 py-1.5 text-sm text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors duration-200"
                disabled={!inputText}
              >
                <Trash2 className="w-4 h-4" />
                <span>清空</span>
              </button>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="请输入文本，用空格分隔不同内容&#10;例如：123 569 7465 8921"
                className="w-full h-64 p-4 border-none outline-none resize-none text-gray-700 placeholder-gray-400 leading-relaxed"
                style={{ fontFamily: 'Monaco, Menlo, "Ubuntu Mono", monospace' }}
              />
              <div className="px-4 py-2 bg-gray-50 border-t border-gray-100">
                <p className="text-xs text-gray-500">
                  字符数: {inputText.length} | 文本块数: {inputText.trim() ? inputText.trim().split(/\s+/).filter(t => t.length > 0).length : 0}
                </p>
              </div>
            </div>
          </div>

          {/* 输出区域 */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-800 flex items-center space-x-2">
                <ArrowRight className="w-5 h-5 text-blue-500" />
                <span>输出结果</span>
              </h2>
              <button
                onClick={handleCopy}
                disabled={!outputText}
                className={`flex items-center space-x-2 px-4 py-2 text-sm font-medium rounded-lg transition-all duration-200 ${
                  copySuccess 
                    ? 'bg-green-100 text-green-700 border border-green-200' 
                    : outputText 
                      ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-sm hover:shadow-md' 
                      : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                }`}
              >
                <Copy className="w-4 h-4" />
                <span>{copySuccess ? '已复制!' : '复制结果'}</span>
              </button>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="p-4">
                {outputText ? (
                  <div 
                    className="text-gray-700 leading-relaxed break-all"
                    style={{ fontFamily: 'Monaco, Menlo, "Ubuntu Mono", monospace' }}
                  >
                    {outputText}
                  </div>
                ) : (
                  <div className="text-gray-400 italic">
                    转换结果将在此显示...
                  </div>
                )}
              </div>
              <div className="px-4 py-2 bg-gray-50 border-t border-gray-100">
                <p className="text-xs text-gray-500">
                  输出长度: {outputText.length}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* 使用说明 */}
        <div className="mt-12 bg-white/60 backdrop-blur-sm rounded-xl border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">使用说明</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-gray-700 mb-2">输入格式</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• 在左侧输入框中输入文本</li>
                <li>• 使用空格分隔不同的文本块</li>
                <li>• 支持多个连续空格</li>
                <li>• 自动忽略首尾空格</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-gray-700 mb-2">输出格式</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• 右侧自动显示转换结果</li>
                <li>• 文本块用英文逗号分隔</li>
                <li>• 点击"复制结果"快速复制</li>
                <li>• 支持记事本等文本编辑器粘贴</li>
              </ul>
            </div>
          </div>
          
          <div className="mt-4 p-3 bg-blue-50 rounded-lg">
            <p className="text-sm text-blue-700">
              <strong>示例：</strong> 输入 "123 569 7465 8921" → 输出 "123,569,7465,8921"
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;